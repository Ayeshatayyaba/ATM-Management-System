import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

public class BankClass {
    private final String Name;
    private final String Cnic;
    private final String initialDeposit;
    private final String depositAmount;

    // Constructor to initialize booking data
    public BankClass(String Name, String Cnic, String initialDeposit, String depositAmount) {
        this.Name = Name;
        this.Cnic = Cnic;
        this.initialDeposit = initialDeposit;
        this.depositAmount = depositAmount;
    }

    // Method to save booking data to the file
    public static void saveBooking(BankClass booking) {
        File file = new File("data.txt");

        try {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true)) // Open in append mode
                ) {
                writer.write(booking.Name + "," + booking.Cnic + "," + booking.initialDeposit + "," + booking.depositAmount + "," );
                writer.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error while saving booking information.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
}

package com.mycompany.home;
public class BankAccount {
    private Customer customer;

    public BankAccount(Customer customer) {
        this.customer = customer;
    }

    public void displayAccountDetails() {
        System.out.println("Account Holder: " + customer.getName());
        System.out.println("CNIC: " + customer.getCnic());
        System.out.println("Account No: " + customer.getAccountNo());
        System.out.println("Card No: " + customer.getCard());
        System.out.println("Balance: " + customer.getBalance());
    }
}


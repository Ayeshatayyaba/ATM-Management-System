import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class checkbalanceClass extends JFrame {

    private JTextField displayField; // Display field for showing numbers

    public checkbalanceClass() {
        // Frame settings
        setTitle("ATM Machine");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 600);
        setLayout(null);

        // Display field
        displayField = new JTextField("00000");
        displayField.setFont(new Font("Arial", Font.BOLD, 30));
        displayField.setHorizontalAlignment(JTextField.CENTER);
        displayField.setEditable(false);
        displayField.setBounds(50, 50, 300, 50);
        add(displayField);

        // Buttons
        addNumberButtons();
        addFunctionButtons();

        setVisible(true);
    }

    private void addNumberButtons() {
        int x = 50, y = 120; // Initial position for number buttons
        for (int i = 1; i <= 9; i++) {
            JButton button = new JButton(String.valueOf(i));
            button.setBounds(x, y, 70, 50);
            button.addActionListener(new NumberButtonListener());
            add(button);

            x += 80; // Move to the right
            if (i % 3 == 0) { // Move to the next row
                x = 50;
                y += 60;
            }
        }

        // Add 0 button
        JButton button0 = new JButton("0");
        button0.setBounds(50, y + 60, 150, 50); // Double size for "0"
        button0.addActionListener(new NumberButtonListener());
        add(button0);
    }

    private void addFunctionButtons() {
        JButton clearButton = new JButton("Clear");
        clearButton.setBounds(220, 300, 100, 50);
        clearButton.setBackground(Color.ORANGE);
        clearButton.addActionListener(e -> displayField.setText("00000"));
        add(clearButton);

        JButton cancelButton = new JButton("Cancel");
        cancelButton.setBounds(220, 360, 100, 50);
        cancelButton.setBackground(Color.RED);
        cancelButton.addActionListener(e -> System.exit(0)); // Exit the application
        add(cancelButton);

        JButton enterButton = new JButton("Enter");
        enterButton.setBounds(220, 420, 100, 50);
        enterButton.setBackground(Color.GREEN);
        enterButton.addActionListener(e -> JOptionPane.showMessageDialog(this, "Entered: " + displayField.getText()));
        add(enterButton);
    }

    // Listener class for number buttons
    private class NumberButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String currentText = displayField.getText();
            String buttonText = ((JButton) e.getSource()).getText();
            if (currentText.equals("00000")) {
                displayField.setText(buttonText);
            } else {
                displayField.setText(currentText + buttonText);
            }
        }
    }

    public static void main(String[] args) {
        new checkbalanceClass();
    }
}

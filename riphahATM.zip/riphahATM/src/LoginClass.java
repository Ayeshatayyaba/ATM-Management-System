import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginClass extends JFrame {
    public LoginClass() {
        
        setTitle("Riphah Bank Login");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

       
        JLabel titleLabel = new JLabel("Riphah Bank Login");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setBounds(100, 30, 200, 30);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(titleLabel);

       
        JLabel keyLabel = new JLabel("Key");
        keyLabel.setFont(new Font("Arial", Font.BOLD, 16));
        keyLabel.setForeground(Color.GREEN);
        keyLabel.setBounds(50, 100, 100, 30);
        add(keyLabel);

        
        JTextField keyField = new JTextField();
        keyField.setBounds(120, 100, 200, 30);
        add(keyField);

       
        JButton loginButton = new JButton("Login");
        loginButton.setFont(new Font("Arial", Font.BOLD, 16));
        loginButton.setForeground(Color.RED);
        loginButton.setBounds(150, 160, 100, 30);
        add(loginButton);

        
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String inputKey = keyField.getText();
                if (inputKey.equals("1234")) {
                    JOptionPane.showMessageDialog(null, "Login Successful!");
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid Key! Try again.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LoginClass login = new LoginClass();
            login.setVisible(true);
        });
    }
}                              

